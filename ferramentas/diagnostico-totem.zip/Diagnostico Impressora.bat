@echo off
rem Roda o diagnostico da impressora do totem (pede confirmacao antes de qualquer mudanca)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0diagnostico-impressora.ps1"
