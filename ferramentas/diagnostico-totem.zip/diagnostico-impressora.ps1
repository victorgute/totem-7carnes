﻿# Diagnóstico da impressora do totem (7 Carnes Burger)
# Verifica impressora, porta, fila, impressora padrão e Chrome; faz um teste direto na impressora
# e oferece correções. Nada é alterado sem perguntar antes.
# Uso: dois cliques em "Diagnostico Impressora.bat" (ou: powershell -ExecutionPolicy Bypass -File diagnostico-impressora.ps1)
param([switch]$SoDiagnostico)   # -SoDiagnostico: só lê, não pergunta nem altera nada

$ErrorActionPreference = "Continue"
$desktop = [Environment]::GetFolderPath("Desktop")
$relatorio = Join-Path $desktop "diagnostico-impressora.txt"
try { Start-Transcript -Path $relatorio -Force | Out-Null } catch {}

$URL_TOTEM = "https://victorgute.github.io/totem-7carnes/"
$resumo = New-Object System.Collections.Generic.List[string]

function Titulo($t) { Write-Host ""; Write-Host "=== $t ===" -ForegroundColor Cyan }
function Ok($t)     { Write-Host "  [OK] $t" -ForegroundColor Green }
function Aviso($t)  { Write-Host "  [!]  $t" -ForegroundColor Yellow; $script:resumo.Add($t) }
function Info($t)   { Write-Host "       $t" }
function Perguntar($t) {
    if ($SoDiagnostico) { return $false }
    $r = Read-Host "  >> $t (S/N)"
    return ($r -match '^[sS]')
}

Write-Host "Diagnostico da impressora do totem - $(Get-Date -Format 'dd/MM/yyyy HH:mm')" -ForegroundColor White
Write-Host "O relatorio fica salvo em: $relatorio"

# ------------------------------------------------------------------ 1. impressoras
Titulo "1. Impressoras instaladas"
$imps = @(Get-CimInstance Win32_Printer -ErrorAction SilentlyContinue)
foreach ($p in $imps) {
    $pad = ""; if ($p.Default) { $pad = "  <- PADRAO" }
    Info ("{0}  |  porta: {1}  |  driver: {2}{3}" -f $p.Name, $p.PortName, $p.DriverName, $pad)
}
$alvo = $imps | Where-Object { $_.Name -match 'POS-?58' } | Select-Object -First 1
if (-not $alvo) {
    Aviso "Nao encontrei uma impressora com 'POS-58' no nome."
    if (-not $SoDiagnostico) {
        $nome = Read-Host "  >> Digite o nome exato da impressora do totem (como aparece acima)"
        $alvo = $imps | Where-Object { $_.Name -eq $nome } | Select-Object -First 1
    }
}
if (-not $alvo) { Aviso "Sem impressora para testar. Encerrando."; try { Stop-Transcript | Out-Null } catch {}; if (-not $SoDiagnostico) { Read-Host "Enter para sair" }; exit }
Ok "Impressora do totem: $($alvo.Name)"

# ------------------------------------------------------------------ 2. status e porta
Titulo "2. Status e porta"
if ($alvo.WorkOffline) { Aviso "A impressora esta marcada como OFFLINE (trabalhar offline)." } else { Ok "Nao esta offline" }
$estados = @{ 1 = "Outro"; 2 = "Desconhecido"; 3 = "Pronta"; 4 = "Imprimindo"; 5 = "Aquecendo"; 6 = "Parada"; 7 = "Offline" }
$st = $estados[[int]$alvo.PrinterStatus]; if (-not $st) { $st = "$($alvo.PrinterStatus)" }
Info "Status informado pelo Windows: $st"
if ($alvo.PortName -match '^USB') { Ok "Porta USB: $($alvo.PortName)" }
else { Aviso "A porta e '$($alvo.PortName)', nao USB. A impressora e USB: a porta deveria ser USB001, USB002..." }
$usb = @(Get-PrinterPort -ErrorAction SilentlyContinue | Where-Object { $_.Name -like 'USB*' })
Info ("Portas USB de impressora existentes: " + (($usb | ForEach-Object { $_.Name }) -join ", "))

# ------------------------------------------------------------------ 3. fila
Titulo "3. Fila de impressao"
$jobs = @(Get-PrintJob -PrinterName $alvo.Name -ErrorAction SilentlyContinue)
if ($jobs.Count -eq 0) { Ok "Fila vazia" }
else {
    Aviso "$($jobs.Count) trabalho(s) parado(s) na fila (podem travar os proximos)."
    $jobs | ForEach-Object { Info ("#{0} {1} - {2}" -f $_.Id, $_.DocumentName, $_.JobStatus) }
    if (Perguntar "Cancelar todos os trabalhos parados?") {
        $jobs | ForEach-Object { Remove-PrintJob -PrinterName $alvo.Name -ID $_.Id -ErrorAction SilentlyContinue }
        Ok "Fila limpa"
    }
}

# ------------------------------------------------------------------ 4. impressora padrão
Titulo "4. Impressora padrao do Windows"
$padrao = $imps | Where-Object { $_.Default } | Select-Object -First 1
if ($padrao -and $padrao.Name -eq $alvo.Name) { Ok "A padrao ja e $($alvo.Name)" }
else { Aviso ("A padrao e '{0}', nao a impressora do totem." -f $(if ($padrao) { $padrao.Name } else { "(nenhuma)" })) }
$chaveWin = "HKCU:\Software\Microsoft\Windows NT\CurrentVersion\Windows"
$legacy = (Get-ItemProperty -Path $chaveWin -Name LegacyDefaultPrinterMode -ErrorAction SilentlyContinue).LegacyDefaultPrinterMode
if ($legacy -eq 1) { Ok "'Deixar o Windows gerenciar minha impressora padrao' esta DESATIVADO" }
else { Aviso "'Deixar o Windows gerenciar minha impressora padrao' esta ATIVADO (a padrao muda sozinha)." }

# ------------------------------------------------------------------ 5. teste direto
Titulo "5. Teste direto na impressora (sem navegador, comandos ESC/POS)"
$codigoRaw = @"
using System; using System.Runtime.InteropServices;
public class RawPrinterTotem {
  [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
  public class DOCINFO { [MarshalAs(UnmanagedType.LPWStr)] public string pDocName; [MarshalAs(UnmanagedType.LPWStr)] public string pOutputFile; [MarshalAs(UnmanagedType.LPWStr)] public string pDataType; }
  [DllImport("winspool.drv", CharSet = CharSet.Unicode, SetLastError = true)] static extern bool OpenPrinter(string n, out IntPtr h, IntPtr d);
  [DllImport("winspool.drv", SetLastError = true)] static extern bool ClosePrinter(IntPtr h);
  [DllImport("winspool.drv", CharSet = CharSet.Unicode, SetLastError = true)] static extern bool StartDocPrinter(IntPtr h, int level, [In] DOCINFO di);
  [DllImport("winspool.drv", SetLastError = true)] static extern bool EndDocPrinter(IntPtr h);
  [DllImport("winspool.drv", SetLastError = true)] static extern bool StartPagePrinter(IntPtr h);
  [DllImport("winspool.drv", SetLastError = true)] static extern bool EndPagePrinter(IntPtr h);
  [DllImport("winspool.drv", SetLastError = true)] static extern bool WritePrinter(IntPtr h, byte[] b, int c, out int w);
  public static string Enviar(string impressora, byte[] dados) {
    IntPtr h;
    if (!OpenPrinter(impressora, out h, IntPtr.Zero)) return "ERRO ao abrir a impressora (codigo " + Marshal.GetLastWin32Error() + ")";
    var di = new DOCINFO { pDocName = "Teste Totem 7 Carnes", pDataType = "RAW" };
    if (!StartDocPrinter(h, 1, di)) { int e = Marshal.GetLastWin32Error(); ClosePrinter(h); return "ERRO ao iniciar documento (codigo " + e + ")"; }
    StartPagePrinter(h); int w; bool ok = WritePrinter(h, dados, dados.Length, out w);
    EndPagePrinter(h); EndDocPrinter(h); ClosePrinter(h);
    return ok ? "enviado (" + w + " bytes)" : "ERRO ao enviar (codigo " + Marshal.GetLastWin32Error() + ")";
  }
}
"@
$saiuDireto = $null
if (Perguntar "Enviar um teste direto para '$($alvo.Name)'?") {
    try {
        Add-Type -TypeDefinition $codigoRaw -ErrorAction Stop
        $txt = "7 CARNES BURGER`nTESTE DIRETO DE IMPRESSAO`n$(Get-Date -Format 'dd/MM/yyyy HH:mm')`n--------------------------------`nSe voce le isto, a impressora`ne o Windows estao OK.`n"
        $bytes = New-Object System.Collections.Generic.List[byte]
        $bytes.AddRange([byte[]](0x1B, 0x40, 0x1B, 0x61, 0x01))            # inicializa e centraliza
        $bytes.AddRange([System.Text.Encoding]::ASCII.GetBytes($txt))
        $bytes.AddRange([byte[]](0x1B, 0x64, 0x05, 0x1D, 0x56, 0x00))      # avança papel e corta (se tiver guilhotina)
        $res = [RawPrinterTotem]::Enviar($alvo.Name, $bytes.ToArray())
        Info "Resultado do envio: $res"
        $r = Read-Host "  >> Saiu papel com o texto 'TESTE DIRETO DE IMPRESSAO'? (S = sim / B = saiu em branco / N = nao saiu nada)"
        $saiuDireto = $r.ToUpper()
        if ($saiuDireto -eq "S") { Ok "Impressora e Windows funcionando" }
        elseif ($saiuDireto -eq "B") { Aviso "Saiu papel em branco: o rolo termico provavelmente esta VIRADO. Vire o rolo e teste de novo." }
        else { Aviso "O teste direto nao imprimiu: o problema esta na impressora/cabo/porta/driver, nao no app." }
    } catch { Aviso "Falha no teste direto: $($_.Exception.Message)" }
}
if (Perguntar "Imprimir tambem a pagina de teste do Windows?") {
    try { Invoke-CimMethod -InputObject $alvo -MethodName PrintTestPage | Out-Null; Info "Pagina de teste enviada. Veja se saiu." }
    catch { Aviso "Nao consegui enviar a pagina de teste: $($_.Exception.Message)" }
}

# ------------------------------------------------------------------ 6. Chrome
Titulo "6. Navegador"
$chrome = @("$env:ProgramFiles\Google\Chrome\Application\chrome.exe", "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe", "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
$edge = @("${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe", "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
if ($chrome) { Ok "Chrome: $chrome" } else { Info "Chrome nao instalado" }
if ($edge) { Ok "Edge: $edge" }
$abertos = @(Get-Process chrome -ErrorAction SilentlyContinue)
if ($abertos.Count -gt 0) { Aviso "O Chrome esta aberto ($($abertos.Count) processos). Com ele aberto, o modo quiosque e a impressao silenciosa sao IGNORADOS." }
else { Ok "Chrome fechado" }

$perfis = @(Get-ChildItem "$env:LOCALAPPDATA\Google\Chrome\User Data" -Directory -ErrorAction SilentlyContinue | Where-Object { Test-Path (Join-Path $_.FullName "Preferences") })
if ($perfis.Count -eq 0) { Info "Nenhum perfil do Chrome encontrado." }
foreach ($perfil in $perfis) {
    $prefs = Join-Path $perfil.FullName "Preferences"
    Info "Perfil do Chrome: $($perfil.Name)"
    try {
        $j = Get-Content $prefs -Raw -Encoding UTF8 | ConvertFrom-Json
        $estado = $j.printing.print_preview_sticky_settings.appState
        if ($estado) {
            $app = $estado | ConvertFrom-Json
            $dest = @($app.recentDestinations) | Select-Object -First 1
            if ($dest) {
                Info "Ultima impressora escolhida no Chrome: $($dest.displayName) [$($dest.id)]"
                if ($dest.id -match 'Save as PDF|Salvar como PDF|^Save' -or $dest.displayName -match 'PDF') { Aviso "O Chrome esta mandando para 'Salvar como PDF': no modo quiosque o comprovante vira um arquivo, nao papel." }
                elseif ($dest.displayName -ne $alvo.Name -and $dest.id -ne $alvo.Name) { Aviso "O Chrome esta usando '$($dest.displayName)', nao '$($alvo.Name)'." }
                else { Ok "O Chrome ja usa $($alvo.Name)" }
            }
        } else { Info "O Chrome ainda nao tem impressora lembrada." }
    } catch { Info "Nao consegui ler as preferencias do Chrome." }
}
$polChrome = "HKCU:\Software\Policies\Google\Chrome"
$pol = (Get-ItemProperty -Path $polChrome -Name PrintPreviewUseSystemDefaultPrinter -ErrorAction SilentlyContinue).PrintPreviewUseSystemDefaultPrinter
if ($pol -eq 1) { Ok "Chrome configurado para usar a impressora padrao do Windows" }
else { Aviso "O Chrome NAO esta configurado para usar a impressora padrao do Windows." }

# ------------------------------------------------------------------ 7. correções
if (-not $SoDiagnostico) {
    Titulo "7. Correcoes (cada uma pergunta antes)"
    if (-not ($padrao -and $padrao.Name -eq $alvo.Name) -or $legacy -ne 1) {
        if (Perguntar "Definir '$($alvo.Name)' como impressora padrao e impedir o Windows de trocar sozinho?") {
            try {
                Set-ItemProperty -Path $chaveWin -Name LegacyDefaultPrinterMode -Value 1 -Type DWord
                Invoke-CimMethod -InputObject $alvo -MethodName SetDefaultPrinter | Out-Null
                Ok "Padrao definida"
            } catch { Aviso "Nao consegui definir a padrao: $($_.Exception.Message)" }
        }
    }
    if ($pol -ne 1) {
        if (Perguntar "Configurar Chrome e Edge para sempre imprimir na impressora padrao do Windows?") {
            foreach ($k in @($polChrome, "HKCU:\Software\Policies\Microsoft\Edge")) {
                if (-not (Test-Path $k)) { New-Item -Path $k -Force | Out-Null }
                Set-ItemProperty -Path $k -Name PrintPreviewUseSystemDefaultPrinter -Value 1 -Type DWord
            }
            Ok "Configurado (vale na proxima vez que o navegador abrir)"
        }
    }
    if (Perguntar "Criar o atalho 'Iniciar Totem' na area de trabalho (fecha o Chrome e abre o app em tela cheia)?") {
        $bat = Join-Path $desktop "Iniciar Totem.bat"
        $linhas = @(
            "@echo off",
            "rem Abre o app do totem em tela cheia com impressao direta",
            "taskkill /IM chrome.exe /F >nul 2>&1",
            "timeout /t 2 /nobreak >nul",
            "set URL=$URL_TOTEM"
        )
        if ($chrome) { $linhas += "start """" ""$chrome"" --kiosk --kiosk-printing --noerrdialogs --disable-session-crashed-bubble --no-first-run %URL%" }
        elseif ($edge) { $linhas += "start """" ""$edge"" --kiosk %URL% --edge-kiosk-type=fullscreen --kiosk-printing --no-first-run" }
        Set-Content -Path $bat -Value $linhas -Encoding ASCII
        Ok "Atalho criado: $bat"
    }
}

# ------------------------------------------------------------------ resumo
Titulo "Resumo"
if ($resumo.Count -eq 0) { Ok "Nenhum problema encontrado." }
else { Write-Host "  Pontos de atencao:" -ForegroundColor Yellow; $resumo | ForEach-Object { Write-Host "   - $_" -ForegroundColor Yellow } }
Write-Host ""
Write-Host "Proximo passo: abra o totem pelo 'Iniciar Totem' e use 'Imprimir teste' na area da loja (segure o logo 3 s, senha 7777)."
Write-Host "Mande o arquivo '$relatorio' (ou uma foto desta tela) para o Victor."
try { Stop-Transcript | Out-Null } catch {}
if (-not $SoDiagnostico) { Read-Host "Enter para sair" }
